<h1>Bienvenue sur NelDev</h1>
<p>
    Vous pouvez déjà ajouter un nouveau article si vous le voulez <br>
    Cela vous permettra de l'afficher la liste des articles
</p>
<p><a href="index.php?p=ajout">Nouvelle article</a></p>
<p>
    Nous avons plusieurs utilisateurs qui redigent nos articles<br>
    dans le but d'impacter le monde par leur mentalité.
</p>
<p><a href="index.php?p=redacteurs">Liste des redacteurs</a></p>
<p>
    Ou accédez directement à l'ensemble de nos articles écritent par des<br>
    vonlontaires pour chaque domaine aborder...
</p>
<p><a href="index.php?p=articles">Nos articles</a></p>